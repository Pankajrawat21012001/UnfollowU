import React from "react";


const Calculate = props => {

    return (
        <div id='full-calculate' class="display-none detail-size m-auto">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card padding text-center">
                        <div class="card-body">
                            <h2 class="card-title text-center pb-1 fw-bold fs-1">Calculating Time</h2>
                            <h4 class="card-text fw-normal text-center pt-1">It can take some time It mainly depends on the number of followers/following you have 😊</h4>
                            <div class="fa-3x">
                                <p class="spinner loading card-text fw-bolder">
                                    <i class="fas fa-spinner fa-pulse"></i>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Calculate;