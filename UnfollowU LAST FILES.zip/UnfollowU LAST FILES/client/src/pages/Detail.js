import React from "react";


const Detail = props => {

    return (
        <div id="full-detail" class="detail-size m-auto">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                    <div class="left card padding text-center">
                        <div class="card-body">
                            <p class="card-title"><i class="fa-solid fa-user-plus"></i></p>
                            <p class="card-text fw-bolder fs-5">Check who doesn't follow you</p>
                            <p class="card-text fw-normal">check with them why they don't follow you</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                    <div class="right card padding text-center">
                        <div class="card-body">
                            <p class="card-title"><i class="fa-solid fa-user-minus"></i></p>
                            <p class="card-text fw-bolder fs-5">Find out who you don't follow</p>
                            <p class="card-text fw-normal">maybe someone deserve to follow back</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Detail;