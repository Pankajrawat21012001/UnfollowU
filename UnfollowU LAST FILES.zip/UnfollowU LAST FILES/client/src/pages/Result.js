import React from "react";


const Result = props => {

    function leftButton() {
        var leftButton = document.querySelector(".left-button");
        var rightButton = document.querySelector(".right-button");
        var theyPill = document.querySelector("#they");
        var youPill = document.querySelector("#you");

        var resultArea1 = document.querySelector("#result-area-1");
        var resultArea2 = document.querySelector("#result-area-2");

        for (let index = 0; index < leftButton.classList.length; index++) {
            if (leftButton.classList[index] !== ("white-background-onclick")) {
                leftButton.classList.add("white-background-onclick");
                theyPill.classList.add("pill-border");

                resultArea2.classList.add("display-none");
                resultArea1.classList.remove("display-none");

                for (let i = 0; i < rightButton.classList.length; i++) {
                    if (rightButton.classList[i] === ("white-background-onclick")) {
                        rightButton.classList.remove("white-background-onclick");
                        youPill.classList.remove("pill-border");
                        break;
                    }
                }
                break;
            }
        }
    }

    function rightButton() {
        var leftButton = document.querySelector(".left-button");
        var rightButton = document.querySelector(".right-button");
        var theyPill = document.querySelector("#they");
        var youPill = document.querySelector("#you");

        var resultArea1 = document.querySelector("#result-area-1");
        var resultArea2 = document.querySelector("#result-area-2");

        for (let index = 0; index < rightButton.classList.length; index++) {
            if (rightButton.classList[index] !== ("white-background-onclick")) {
                rightButton.classList.add("white-background-onclick");
                youPill.classList.add("pill-border");

                resultArea1.classList.add("display-none");
                resultArea2.classList.remove("display-none");

                for (let i = 0; i < leftButton.classList.length; i++) {
                    if (leftButton.classList[i] === ("white-background-onclick")) {
                        leftButton.classList.remove("white-background-onclick");
                        theyPill.classList.remove("pill-border");
                        break;
                    }
                }
                break;
            }
        }
    }

    return (
        <div id="full-result" class="display-none my-3">
            <div class="result-navbar m-auto">
                <button onClick={leftButton} type="button" class="left-button btn btn-outline-dark btn-lg white-background-onclick">
                    <p class="fw-bolder remove-margin">They Don't Follow You</p>
                    <p id="they" class="pill rounded-pill fw-bold m-auto pill-border"></p>
                </button>
                <button onClick={rightButton} type="button" class="right-button btn btn-outline-dark btn-lg">
                    <p class="fw-bolder remove-margin">You Don't Follow Them</p>
                    <p id="you" class="pill rounded-pill fw-bold m-auto"></p>
                </button>
            </div>
            <div class="result-area m-auto">
                <div class="card text-center">
                    <div class="card-body bg-white no-padding">
                        <div class="container text-center no-padding">
                            <div id="result-area-1" class="row m-3">
                                {/* <div class="col-lg-3 col-md-4 col-sm-6 col-6 p-1 my-3">
                                    <a class='remove-margin  fw-bold' href="https://www.instagram.com/pnkj_singhrawat">pnkj_singhrawat</a>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6 col-6 p-1 my-3">
                                    <a class='remove-margin  fw-bold' href="https://www.instagram.com/pnkj_singhrawat">pnkj_singhrawat</a>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6 col-6 p-1 my-3">
                                    <a class='remove-margin  fw-bold' href="https://www.instagram.com/pnkj_singhrawat">pnkj_singhrawat</a>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6 col-6 p-1 my-3">
                                    <a class='remove-margin  fw-bold' href="https://www.instagram.com/pnkj_singhrawat">pnkj_singhrawat</a>
                                </div> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="result-area m-auto">
                <div class="card text-center">
                    <div class="card-body bg-white no-padding">
                        <div class="container text-center no-padding">
                            <div id="result-area-2" class="row m-3 display-none">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Result;