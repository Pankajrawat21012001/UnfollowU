import React from "react";


const ErrorPage = props => {

    return (
        <div id='full-error' class="display-none detail-size m-auto">
            <div class="d-flex align-items-center justify-content-center vh-50 p-1">
                <div class="text-center">
                    <h1 class="display-1 fw-bold fs-1">404</h1>
                    <p class="fs-3"> <span class="text-danger fw-bold">Opps!</span> Result not found.</p>
                    <p id="display-error" class="lead"></p>
                    <a href="/" class="btn btn-dark">Try Again</a>
                </div>
            </div>
        </div>
    );
};

export default ErrorPage;