import React, { useState } from "react";
import Title from "./Title";
import Navbar from "./Navbar";
import Searchbox from "./Searchbox";
import Guide from "./Guide";
import Detail from "./Detail";
import Calculate from "./Calculate";
import Estimated from "./Estimated";
import Result from "./Result";
import ErrorPage from "./ErrorPage";
import Footer from "./Footer";


const Homepage = props => {
    const [username, setUsername] = useState("");

    const onChange = ({ target: { value } }) => {
        setUsername(value);
    };

    function appendNotFollowingYouData(data) {
        var leftPill = document.getElementById("they");
        if(data.length<1000){
            leftPill.textContent = data.length;
        }else if (data.length>=1000 && data.length<1000000){
            leftPill.textContent = Math.round(data.length/1000)+"K";
        }else if(data.length>=1000000){
            leftPill.textContent = Math.round(data.length/1000000)+"M";
        }else{
            console.log("error while writting inside left pill");
            leftPill.textContent = data.length;
        }

        let mainContainer = document.getElementById("result-area-1");
        mainContainer.innerHTML = "";

        if (data.length !== 0) {
            for (let i = 0; i < data.length; i++) {
                let div = document.createElement("div");
                div.classList.add("col-lg-3");
                div.classList.add("col-md-4");
                div.classList.add("col-sm-6");
                div.classList.add("col-6");
                div.classList.add("p-1");
                div.classList.add("my-3");

                let a = document.createElement("a");
                a.classList.add("remove-margin");
                a.classList.add("fw-bold");
                a.href = "https://www.instagram.com/" + data[i].username;
                a.target = "_blank";
                a.innerHTML = "@" + data[i].username;

                // let p = document.createElement("p");
                // p.classList.add("remove-margin");
                // p.innerHTML = data[i].username;

                div.appendChild(a);
                // div.appendChild(p);
                mainContainer.appendChild(div);
            }
            // if (data.length===0){
            //     mainContainer.classList.add("display-none");
            // }
        } else {
            for (let i = 0; i < 1; i++) {
                let div = document.createElement("div");
                div.classList.add("col-lg-12");
                // div.classList.add("col-md-4");
                // div.classList.add("col-sm-6");
                div.classList.add("p-1");
                div.classList.add("m-auto");

                // let a = document.createElement("a");
                // a.classList.add("remove-margin");
                // a.classList.add("fw-bold");
                // a.href = "https://www.instagram.com/" + data[i].username;
                // a.target = "_blank";
                // a.innerHTML = "@" + data[i].username;

                let h3 = document.createElement("h3");
                h3.classList.add("remove-margin");
                h3.innerHTML = "😊 No one 😊";

                // div.appendChild(a);
                div.appendChild(h3);
                mainContainer.appendChild(div);
            }
        }
    }

    function appendNotFollowingThemData(data) {
        var rightPill = document.getElementById("you");
        if(data.length<1000){
            rightPill.textContent = data.length;
        }else if (data.length>=1000 && data.length<1000000){
            rightPill.textContent = Math.round(data.length/1000)+"K";
        }else if(data.length>=1000000){
            rightPill.textContent = Math.round(data.length/1000000)+"M";
        }else{
            console.log("error while writting inside left pill");
            rightPill.textContent = data.length;
        }


        let mainContainer = document.getElementById("result-area-2");
        mainContainer.innerHTML = "";

        if (data.length !== 0) {
            for (let i = 0; i < data.length; i++) {
                let div = document.createElement("div");
                div.classList.add("col-lg-3");
                div.classList.add("col-md-4");
                div.classList.add("col-sm-6");
                div.classList.add("col-6");
                div.classList.add("p-1");
                div.classList.add("my-3");

                let a = document.createElement("a");
                a.classList.add("remove-margin");
                a.classList.add("fw-bold");
                a.href = "https://www.instagram.com/" + data[i].username;
                a.target = "_blank";
                a.innerHTML = "@" + data[i].username;

                // let p = document.createElement("p");
                // p.classList.add("remove-margin");
                // p.innerHTML = data[i].username;

                div.appendChild(a);
                // div.appendChild(p);
                mainContainer.appendChild(div);
            }
        } else {
            for (let i = 0; i < 1; i++) {
                let div = document.createElement("div");
                div.classList.add("col-lg-12");
                // div.classList.add("col-md-4");
                // div.classList.add("col-sm-6");
                div.classList.add("p-1");
                div.classList.add("m-auto");

                // let a = document.createElement("a");
                // a.classList.add("remove-margin");
                // a.classList.add("fw-bold");
                // a.href = "https://www.instagram.com/" + data[i].username;
                // a.target = "_blank";
                // a.innerHTML = "@" + data[i].username;

                let h3 = document.createElement("h3");
                h3.classList.add("remove-margin");
                h3.innerHTML = "😊 No one 😊";

                // div.appendChild(a);
                div.appendChild(h3);
                mainContainer.appendChild(div);
            }
        }

    }
    var doneCounting = false;
    var doneScraping = false;



    function countTime(cnt) {
        // console.log("Estimated time is :-" + (45 + cnt[1] + cnt[2]) + "seconds");
        doneCounting = true;
        const totalSeconds = 45 + Math.floor(cnt[1]/2) + Math.floor(cnt[2]/2);

        const minutes = Math.floor(totalSeconds/60);
        const seconds = totalSeconds%60;

        function padTo2Digits(num) {
            return num.toString().padStart(2, '0');
        }

        // setTime();
        // time=45 + cnt[1] + cnt[2];
        // let d;
        // d = new Date();
        // d.setSeconds(d.getSeconds() + (45 + cnt[1] + cnt[2]));
        // console.log(d);
        return ` ${padTo2Digits(minutes)}m : ${padTo2Digits(seconds)}s`;
        // console.log("receiveCOunt");
    }

    function waitFor(conditionFunction) {

        const poll = resolve => {
            if (conditionFunction()) resolve();
            else setTimeout(_ => poll(resolve), 400);
        }

        return new Promise(poll);
    }

    async function displayError(ErrorType) {
        console.log(ErrorType);

        var fullError = document.querySelector("#full-error");
        fullError.classList.remove("display-none");

        var displayError = document.querySelector("#display-error");
        if (ErrorType.Detail === undefined) {
            displayError.innerHTML = "There may be something wrong Please try Again";
        } else {
            displayError.innerHTML = ErrorType.Detail;
        }


        let fullEstimated = document.querySelector("#full-estimated");
        fullEstimated.classList.add("display-none");

        let fullCalculate = document.querySelector("#full-calculate");
        fullCalculate.classList.add("display-none");

        // let countdown = document.querySelector("#countdown");
        // console.log("POINT 3");
        // countdown.innerHTML = "EXPIRED";
        // let countdown = document.querySelector("#countdown");
        // countdown.innerHTML = "";


        await new Promise(r => setTimeout(r, 5000));

        fullError.classList.add("display-none");
        displayError.innerHTML = "";

        window.location.reload(false);

    }

    var workInProgress=0;
    async function onClick() {
        if (workInProgress===0) {
            workInProgress=1;
            doneCounting = false;
            doneScraping = false;
            var Error = false;
            let fullResult = document.querySelector("#full-result");
            fullResult.classList.add("display-none");
    
            fetch(`/api/count/${username}`)
                .then(res => res.json())
                .then(cnt => {
                    // console.log('onclick count data');
                    // console.log(countTime(cnt));
                    doneCounting = false;
                    // console.log("cnt is :-",cnt);
                    // console.log("Time errror",timeRequire);
                    if (cnt.ErrorName === "CountFileERROR" || cnt.ErrorName === "CountPromptERROR") {
                        Error = true;
                        displayError(cnt);
                        console.log("Error Point 1");
                    } else {
                        // console.log(timeRequire);
                        // let countdown = document.querySelector("#countdown");
                        let timer = document.querySelector("#timer");
                        var timeRequire = countTime(cnt);
                        // var timeRequire = 100;
                        // console.log("TimeRequire value :-",timeRequire);
                        // countdown.innerHTML = timeRequire;
                        timer.innerHTML = timeRequire;
                        // data.innerHTML = timeRequire;
                        // countdown.innerHTML = countTime(cnt);
                        // console.log("above is from non login");
                    }
                }).catch(function (err) {
                    // console.log(err);
                    Error = true;
                    displayError(err);
                    console.log("Error Point 2");
                });
    
            fetch(`/api/${username}`)
                .then(res => res.json())
                .then(data => {
                    // console.log("Start");
                    // console.log("data", data);
                    switch (data.ErrorName) {
                        case "LoginERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "TypeInputERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "LoginFailedERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "NoUserERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "FollowersFollowingCountERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "FollowersPromptERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "FollowersScrollingERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "FollowersUsernameERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "FollowingPromptERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "FollowingScrollingERROR":
                            displayError(data)
                            Error = true;
                            break;
                        case "FollowingUsernameERROR":
                            displayError(data)
                            Error = true;
                            break;
                        default:
                            break;
                    }
    
                    if (Error === false) {
                        appendNotFollowingYouData(data.notFollowingYou);
                        appendNotFollowingThemData(data.notFollowingThem);
    
                        doneScraping = true;
    
                        let fullResult = document.querySelector("#full-result");
                        fullResult.classList.remove("display-none");
                    }
    
    
                })
                .catch(function (err) {
                    console.log(err);
                    displayError(err);
                    Error = true;
                    console.log("Error Point 4");
                });
    
    
            if (Error === false) {
                await new Promise(r => setTimeout(r, 1000));
                var fullDetail = document.querySelector("#full-detail");
                fullDetail.classList.add("display-none");
    
    
                let fullCalculate = document.querySelector("#full-calculate");
                fullCalculate.classList.remove("display-none");
                await waitFor(_ => doneCounting === true);
    
                fullCalculate.classList.add("display-none");
    
    
                let fullEstimated = document.querySelector("#full-estimated");
                fullEstimated.classList.remove("display-none");
    
                // let countdown = document.querySelector("#countdown");
                // countdown.innerHTML = timeRequire;
                // await new Promise(r => setTimeout(r, 10000));
                await waitFor(_ => doneScraping === true);
                // let timeRequire=countTime(cnt)
                // console.log(timeRequire);
                // console.log("POINT 1");
                // countdown.innerHTML = "EXPIRED";
                // countdown.innerHTML = "Wait a Second";
                fullEstimated.classList.add("display-none");
    
    
                // fullDetail.classList.remove("display-none");
                window.scrollBy(0, 500);
                workInProgress=0;
                doneCounting=false;
            }
        }
    };

    return (
        <div>
            <Navbar />
            <Title />
            <Searchbox value={username} onChange={onChange} onClick={onClick} />
            <Guide />
            <Detail />
            <Calculate />
            <Estimated />
            <ErrorPage />
            <Result />
            <Footer />
        </div>
    );
};

export default Homepage;