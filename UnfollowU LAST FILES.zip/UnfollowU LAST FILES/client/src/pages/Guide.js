import React from "react";


const Guide = props => {

    return (
        <div>
            <div class="py-5">
                <h3 class="guide-top text-white text-center pb-3 fw-normal">Type in the Instagram username to begin.</h3>
                <h5 class="guide-bottom text-white text-center pt-3 fw-light">We'll show you who doesn't follow you as well as who you don't follow.</h5>
            </div>
        </div>
    );
};

export default Guide;