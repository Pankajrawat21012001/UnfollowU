import React from "react";
import logoImg from "../images/logo.png";

const Navbar = props => {

    return (
        <nav class="navbar bg-transparent ">
            <div class="d-flex m-auto text-white"> 
                <h1  class="align-self-center text-white m-auto fs-1 logo"><img src={logoImg} alt="UnfollowU" /></h1>
            </div>
        </nav>
    );
};

export default Navbar;