import React from "react";


const Searchbox = props => {

    return (
        <div class="searchArea">
            <div class="input-group input-group-lg p-5 m-auto">
                <span class="attherate input-group-text"><i class="fa-solid fa-at bg-light"></i></span>
                <input value={props.value} onChange={props.onChange} type="text" class="form-control" spellCheck="false" placeholder="Enter Username" autoFocus ></input>
                
                <button onClick={props.onClick} class="input-group-text btn btn-outline-light btn-lg btn-light" type="button" id="search_button">
                </button>
            </div>
            <div class="w-30 m-auto">
                <h6 class="warning text-white m-auto">* Only public account</h6>
            </div>
        </div>
    );
};

export default Searchbox;