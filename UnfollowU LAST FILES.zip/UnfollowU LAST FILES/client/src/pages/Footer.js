import React from "react";


const Footer = props => {

    return (
        <footer id="sticky-footer" class="fixed-bottom flex-shrink-0 bg-black text-white">
        <div class="container text-center">
          <small>Copyright &copy; <strong>UnfollowU</strong></small>
        </div>
      </footer>
    );
};

export default Footer;