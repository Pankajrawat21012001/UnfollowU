import React from "react";


const Title = props => {

    return (
        <div>
            <div class="text-white pt-6">
                <h1 class="heading">Find out who's not following?</h1>
            </div>
        </div>
    );
};

export default Title;