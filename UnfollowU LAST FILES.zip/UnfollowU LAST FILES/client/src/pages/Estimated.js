import React from "react";


const Estimated = props => {

    return (
        <div id='full-estimated' class="display-none detail-size m-auto">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card padding text-center">
                        <div class="card-body">
                            <h2 class="card-title text-center  fw-bold fs-1">Estimated Time</h2>
                            <span class="card-text">*Come back after<strong class="fs-2 fw-bold" id='timer'></strong></span>
                            <p class="spinner loading card-text fw-bolder">
                                    <i class="fas fa-spinner fa-pulse"></i>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Estimated;