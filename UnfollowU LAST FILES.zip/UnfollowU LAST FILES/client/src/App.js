import React from "react";
import Homepage from "./pages/Homepage";
import './App.css';

const App = () => {
    return (
        <Homepage />
    );
};

export default App;