const puppeteer = require('puppeteer');

const counting = async (username) => {
  const browser = await puppeteer.launch({
    args: ['--incognito'],
    // headless: false,
    headless: true,
  });
  const page = await browser.newPage();
  try {
    await page.goto(`http://www.instagram.com/${username}`, {
      waitUntil: 'networkidle2',
    });

    try {
      await page.waitForSelector('header>section >ul >li', { timeout: 45000 });
    } catch (error) {
      console.log('Got Error while Getting followers and following');
      // console.log(error);
      await browser.close();
      return {
        ErrorName: 'CountPromptERROR',
        Detail:
          'The username has not been detected. Please check the username or check the Internet service.😔',
      };
    }

    var stringCount = await page.$$eval(
      'header>section >ul >li  span span',
      (options) => options.map((option) => String(option.textContent))
    );
  } catch (error) {
    console.log('Got Error while Running Count');
    // console.log(error);
    await browser.close();
    return {
      ErrorName: 'CountFileERROR',
      Detail: 'Please check the Internet Connectivity.😔',
    };
  }
  var availCount = [];
  for (let index = 0; index < stringCount.length; index++) {
    stringCount[index] = stringCount[index].replace(/\,/g, '');
    // availCount[index] = Number(stringCount[index]);
    var regExp = /[a-zA-Z]/g;

    if (regExp.test(stringCount[index])) {
      /* do something if letters are found in your string */
      // console.log(stringCount[index]);
      // console.log(stringCount[index].slice(-1));
      if (stringCount[index].slice(-1) === 'K') {
        availCount[index] =
          Number(stringCount[index].slice(0, stringCount[index].length - 1)) *
          1000;
      }
      // console.log(stringCount[index].slice(-1));
      if (stringCount[index].slice(-1) === 'M') {
        availCount[index] =
          Number(stringCount[index].slice(0, stringCount[index].length - 1)) *
          1000000;
      }
    } else {
      /* do something if letters are not found in your string */
      availCount[index] = Number(stringCount[index]);
    }
  }

  // console.log(availCount);
  await browser.close();
  return availCount;
};

// console.log(count('pnkj_singhrawat'));

module.exports = { counting };
