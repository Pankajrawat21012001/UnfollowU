const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
// const webpack = require("webpack");
// const webpackDevMiddleware = require("webpack-dev-middleware");
// const webpackHotMiddleware = require("webpack-hot-middleware");
// const config = require(path.join(__dirname, "../webpack.config.js"));
// const compiler = webpack(config);
const app = express();

app.use(bodyParser.json({limit:'30mb',extended:true}));
app.use(bodyParser.urlencoded({limit:'30mb',extended:true}));
app.use(cors());


const { script } = require("./script");
const { counting } = require("./count");
const PORT = process.env.PORT || 5000
// app.set("view engine",'ejs')

// app.use(webpackDevMiddleware(compiler, config.devServer));
// app.use(webpackHotMiddleware(compiler));
// app.use(express.static(path.join(__dirname, '../build')));

// app.use((req,res,next)=>{
//     res.setHeader('Access-Control-Allow-Origin','*');
//     res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,PATCH,DELETE');
//     res.setHeader('Access-Control-Allow-Methods','Content-Type','Authorization');
//     next(); 
// })

// app.use(express.static((__dirname, '../client/src')));

app.get("/api/count/:username", async (req, res) => {
    try {
        console.log(`starting script for user ${req.params.username}`);
        const ansCount = await counting(req.params.username);
        // console.log(ansCount);
        res.send(ansCount);
    } catch (error) {
        console.log(error);
        res.send(error);
    }
    // console.log(ansCount);
})

app.get("/api/:username", async (req, res) => {
    try {
        const data = await script(req.params.username);
        console.log(`stopping script for user ${req.params.username}`);
        res.send(data);
    } catch (error) {
        console.log(error);
        res.send(error);
    }
    // const data = await script("gp811065");

});

app.get('/*', async (req, res) => {
    // res.sendFile(__dirname + '/index.html');
    // res.json({"users":[1,2,3,4,5,6,7,8,9]});
    res.send("This is from express.js");

});

app.listen(PORT, function (req, res) {
    console.log(`Server started at port ${PORT}`);
});

// node index.js to run the file