const puppeteer = require('puppeteer');
const { scrollPageToBottom } = require('puppeteer-autoscroll-down');

const accounts = {
  1: ['pnkjrwt1001', 'P@nk@jr@w@t'],
  2: ['pnkjrwt1002', 'P@nk@jr@w@t'],
  3: ['pnkjrwt1003', 'P@nk@jr@w@t'],
  4: ['pnkjrwt1004', 'P@nk@jr@w@t'],
  5: ['pnkjrwt1005', 'P@nk@jr@w@t'],
};

const script = async (username) => {
  try {
    await browser.close();
  } catch (error) {
    console.log('closed the unwanted page');
  }
  const browser = await puppeteer.launch({
    args: ['--incognito'],
    // headless: false,
    headless: true,
  });
  const page = await browser.newPage(); //It is used for creating new page
  // await page.setViewport({
  //     width: 800,
  //     height: 800
  // });
  // await page.goto('http://www.instagram.com/accounts/login', { waitUntil: "networkidle2" });
  await page.goto('http://www.instagram.com/', { waitUntil: 'networkidle2' });

  // await new Promise(r => setTimeout(r, 5000));

  //add waitforselector
  try {
    await page.waitForSelector('form[id="loginForm"]', { timeout: 15000 });
    console.log('Got the form');
  } catch (error) {
    console.log('Got Error while Login Form');
    // console.log(error);
    await browser.close();
    // return "LoginERROR";
    return {
      ErrorName: 'LoginERROR',
      Detail:
        'Please try again. There could be an issue with the network or the server.😔',
    };
  }

  // console.log(accounts.length);
  const randomAccountNumber = Math.floor(
    Math.random() * Object.keys(accounts).length + 1
  );

  // console.log(accounts[randomAccountNumber][0]);
  // console.log(accounts[randomAccountNumber][1]);
  try {
    await page.type('input[name=username]', accounts[randomAccountNumber][0], {
      delay: 20,
    });
    await page.type('input[name=password]', accounts[randomAccountNumber][1], {
      delay: 20,
    });
  } catch (error) {
    console.log('Got Error while Putting Input to Form');
    // console.log(error);
    await browser.close();
    // return "TypeInputERROR";
    return {
      ErrorName: 'TypeInputERROR',
      Detail:
        'Please try again. There could be an issue with the network or the server.😔',
    };
  }

  try {
    await page.click('button[type=submit]', { delay: 20 });
  } catch (error) {
    console.log('Login Failed');
    console.log('Got Error while Login Failed clicking login button');
    // console.log(error);
    await browser.close();
    // return "LoginFailedERROR";
    return {
      ErrorName: 'LoginFailedERROR',
      Detail:
        'Please try again. There could be an issue with the network or the server.😔',
    };
  }

  //wait for login to occur
  await new Promise((r) => setTimeout(r, 5000));

  // const notifyBtns = await page.$x("//button[contains(text(), 'Not Now')]");
  // if (notifyBtns.length > 0) {
  //     await notifyBtns[0].click();
  // } else {
  //     console.log("No notification buttons to click.");
  // }
  //IF some notification occurs the it will remove that
  // await new Promise(r => setTimeout(r, 5000));
  try {
    await page.goto(`https://www.instagram.com/${username}`, {
      waitUntil: 'networkidle2',
    }); //goes to the give user name
  } catch (error) {
    console.log(`Not able to go to account ${username}`); //try again
    // console.log(error);
    await browser.close();
    // return "LoginFailedERROR";
    return {
      ErrorName: 'NoUserERROR',
      Detail: 'Please check the username and internet speed and try again.😔',
    };
  }
  // await new Promise(r => setTimeout(r, 5000));
  // const availCount=await page.$$eval("a > div > span > span", options => options.map(option => Number(option.textContent)));
  // const availCount=await page.$$eval("header>section >ul >li  span span", options => options.map(option => Number(option.textContent)));
  try {
    var stringCount = await page.$$eval(
      'header>section >ul >li  span span',
      (options) => options.map((option) => String(option.textContent))
    );
    var availCount = [];
    for (let index = 0; index < stringCount.length; index++) {
      stringCount[index] = stringCount[index].replace(/\,/g, '');
      // availCount[index] = Number(stringCount[index]);
      var regExp = /[a-zA-Z]/g;

      if (regExp.test(stringCount[index])) {
        /* do something if letters are found in your string */
        // console.log(stringCount[index]);
        // console.log(stringCount[index].slice(-1));
        if (stringCount[index].slice(-1) === 'K') {
          availCount[index] =
            Number(stringCount[index].slice(0, stringCount[index].length - 1)) *
            1000;
        }
        // console.log(stringCount[index].slice(-1));
        if (stringCount[index].slice(-1) === 'M') {
          availCount[index] =
            Number(stringCount[index].slice(0, stringCount[index].length - 1)) *
            1000000;
        }
      } else {
        /* do something if letters are not found in your string */
        availCount[index] = Number(stringCount[index]);
      }
    }
    console.log(availCount);
  } catch (error) {
    console.log('Got Error while Getting following/followers Count');
    // console.log(error);
    await browser.close();
    // return "FollowersFollowingCountERROR";
    return {
      ErrorName: 'FollowersFollowingCountERROR',
      Detail: 'Please check the username and internet speed and try again.😔',
    };
  }

  // const followersBtn = await page.$('div[id=react-root] > section > main > div > header > section > ul > li:nth-child(2) > a');
  // const followersBtn = await page.$('header > section >ul >li:nth-child(2) >a');
  // console.log(followersBtn);
  // await followersBtn.evaluate(btn => btn.click());
  //CHANGING URL DIRECTLY TO FOLLOWERS
  await page.goto(`https://www.instagram.com/${username}/followers/`, {
    waitUntil: 'networkidle2',
  });

  //wait till Dialog occurs
  try {
    await page.waitForSelector('div[role="dialog"]', { timeout: 15000 });
  } catch (error) {
    console.log('Got Error while Followers Prompt');
    // console.log(error);
    await browser.close();
    // return "FollowersPromptERROR";
    return {
      ErrorName: 'FollowersPromptERROR',
      Detail: 'Please check the username and internet speed and try again.😔',
    };
  }

  //GETTING THE SUGGESTION
  const suggestFollower = await page.$$eval(
    'div[role="dialog"]  h4',
    (options) => options.map((option) => String(option.textContent))
  );
  console.log('Got Follows Suggestion');
  // console.log("suggestFollower"+suggestFollower);
  // await new Promise(r => setTimeout(r, 5000));

  // const followersDialog = 'div[role="dialog"] > div:nth-child(2)';  //the location has changed
  // const followersDialog = 'div[role="dialog"]:nth-child(2) >div >div >div:nth-child(2)';
  // const followersDialog = 'div[aria-label="Followers"]';
  //SCROLLING FOLLOWERS
  try {
    const followersDialog = 'div[role="dialog"] >div >div >div:nth-child(2)';
    // console.log(page);
    // await page.waitForSelector('div[role="dialog"] > div:nth-child(2) > ul');
    await page.waitForSelector(
      'div[role="dialog"] >div >div >div:nth-child(2) >div',
      { timeout: 15000 }
    );
    await scrollDown(followersDialog, page);
    console.log('Scrolled on Followers');
  } catch (error) {
    // console.log("Not able to Scroll on Followers");
    console.log('Got Error while ScrollING on Followers');
    // console.log(error);
    await browser.close();
    // return "FollowersScrollingERROR";
    return {
      ErrorName: 'FollowersScrollingERROR',
      Detail: 'Please check the username and internet speed and try again.😔',
    };
  }

  // const lastPosition = await scrollPageToBottom(followersDialog, {
  //     size: 500,
  //     delay: 250
  // })
  // console.log(followersDialog);

  // console.log("getting followers");
  // const list1 = await page.$$('div[role="dialog"] >div >div > div:nth-child(2) > ul > div > li > div > div > div:nth-child(2) > div > a');
  // const list1 = await page.$$('div[role="dialog"] >div >div > div:nth-child(2) > ul > div > li > div > div > div:nth-child(2) > div  a');
  try {
    var avatarPaths = [
      'div[role="dialog"] a[style="width: 44px; height: 44px;"] img',
      'div[role="dialog"] span[style="width: 44px; height: 44px;"] img',
    ];
  } catch (error) {
    console.log('Got Error while getting followers username');
    // console.log(error);
    await browser.close();
    // return "FollowersUsernameERROR";
    return {
      ErrorName: 'FollowersUsernameERROR',
      Detail: 'Please check the username and internet speed and try again.😔',
    };
  }

  // let avatarPaths = [
  //     'div[role="dialog"] a[data-testid="user-avatar-link"] img',
  //     'div[role="dialog"] span[data-testid="user-avatar-link"] img'
  // ];
  const followers = await avatarPaths.reduce(async (accProm, path) => {
    const acc = await accProm;
    const arr = await page.$$eval(path, (res) => {
      return res.map((pic) => {
        const alt = pic.getAttribute('alt');
        const strings = alt.split(/(['])/g);
        return {
          username: strings[0],
          // instagram_address :`https://www.instagram.com/${username}/`
          // avatar: pic.getAttribute('src').length > 0 ? pic.getAttribute("src") : "No Photo"
        };
      });
    });
    return acc.concat([...arr]);
  }, Promise.resolve([]));

  // const followers = await Promise.all(list1.map(async item => {
  //     const username = await (await item.getProperty('innerText')).jsonValue();
  //     const pic = pics1.find(p => p.username === username) || { avatar: "" };
  //     return {
  //         username,
  //         avatar: await pic.avatar
  //     }
  // }));
  // console.log(followers);
  // console.log(pics1);
  console.log('Total Followers are :- ' + followers.length);
  // console.log(pics1.length);

  // await new Promise(r => setTimeout(r, 15000));
  // const closeBtn = await page.$('div[role="dialog"] >div >div>div>div>div>div >button');
  // await closeBtn.evaluate(btn => btn.click());

  // await new Promise(r => setTimeout(r, 1000));
  // const followingBtn = await page.$('div[id=react-root] > section > main > div > header > section > ul > li:nth-child(3) > a');
  // await followingBtn.evaluate(btn => btn.click());

  //GETTING FOLLOWING USING CHANGING URL
  await page.goto(`https://www.instagram.com/${username}/following/`, {
    waitUntil: 'networkidle2',
  });
  try {
    //wait till Dialog occurs
    await page.waitForSelector('div[role="dialog"]', { timeout: 15000 });
  } catch (error) {
    console.log('Got Error while Following Prompt');
    // console.log(error);
    await browser.close();
    // return "FollowingPromptERROR";
    return {
      ErrorName: 'FollowingPromptERROR',
      Detail: 'Please check the username and internet speed and try again.😔',
    };
  }

  // await new Promise(r => setTimeout(r, 2000));

  //GETTING THE SUGGESTION
  const suggestFollowing = await page.$$eval(
    'div[role="dialog"]  h4',
    (options) => options.map((option) => String(option.textContent))
  );
  console.log('Got Following Suggestion');

  try {
    // const followingDialog = 'div[role="dialog"] > div:nth-child(3)';
    const followingDialog = 'div[role="dialog"] >div >div >div:nth-child(3)';
    // await page.waitForSelector('div[role="dialog"] > div:nth-child(3) > ul');
    await page.waitForSelector(
      'div[role="dialog"] >div >div >div:nth-child(3) >div',
      { timeout: 15000 }
    );
    await scrollDown(followingDialog, page);
  } catch (error) {
    // console.log("Not able to Scroll on Followers");
    console.log('Got Error while ScrollING on Following');
    // console.log(error);
    await browser.close();
    // return "FollowingScrollingERROR";
    return {
      ErrorName: 'FollowingScrollingERROR',
      Detail: 'Please check the username and internet speed and try again.😔',
    };
  }

  // console.log("getting following");
  // const list2 = await page.$$('div[role="dialog"] > div:nth-child(3) > ul > div > li > div > div > div:nth-child(2) > div > a');
  // const list2 = await page.$$('div[role="dialog"] >div >div > div:nth-child(3) > ul > div > li > div > div > div:nth-child(2) > div  a');
  // await page.waitForSelector('div[role="dialog"] > div:nth-child(3) > ul > div > li > div > div > div > a > img');
  try {
    avatarPaths = [
      'div[role="dialog"] a[style="width: 44px; height: 44px;"] img',
      'div[role="dialog"] span[style="width: 44px; height: 44px;"] img',
    ];
  } catch (error) {
    console.log('Got Error while getting following username');
    // console.log(error);
    await browser.close();
    // return "FollowingUsernameERROR";
    return {
      ErrorName: 'FollowingUsernameERROR',
      Detail: 'Please check the username and internet speed and try again.😔',
    };
  }

  // avatarPaths = [
  //     'div[role="dialog"] a[data-testid="user-avatar-link"] img',
  //     'div[role="dialog"] span[data-testid="user-avatar-link"] img'
  // ]
  const following = await avatarPaths.reduce(async (accProm, path) => {
    const acc = await accProm;
    const arr = await page.$$eval(path, (res) => {
      return res.map((pic) => {
        const alt = pic.getAttribute('alt');
        const strings = alt.split(/[']/g);
        return {
          username: strings[0],
          // instagram_address :`https://www.instagram.com/${username}/`
          // avatar: pic.getAttribute('src')
        };
      });
    });
    return acc.concat([...arr]);
  }, Promise.resolve([]));
  // const following = await Promise.all(list2.map(async item => {
  //     const username = await (await item.getProperty('innerText')).jsonValue()
  //     const pic = pics2.find(p => p.username === username) || { avatar: "" };
  //     return {
  //         avatar: await pic.avatar,
  //         username
  //     };
  // }));
  console.log('Total Following count is :- ' + following.length);
  // console.log(pics2.length);

  // const followerCnt = followers.length;
  // const followingCnt = following.length;
  // console.log(`followers: ${followerCnt}`);
  // console.log(`following: ${followingCnt}`);
  // console.log(followers);
  // console.log(following);

  console.log('Total proper followers availCount :- ' + availCount[1]);
  console.log('Total proper following availCount :- ' + availCount[2]);

  //Getting the text from h4 while prompt is open and check if Suggestion For You is present or not
  if (suggestFollower == 'Suggestions For You') {
    var new_followers = followers.slice(0, availCount[1]);
  } else {
    var new_followers = followers;
  }

  if (suggestFollowing == 'Suggestions For You') {
    var new_following = following.slice(0, availCount[2]);
  } else {
    var new_following = following;
  }

  // console.log(new_followers);
  // console.log(new_following);

  const notFollowingYou = new_following.filter(
    (item) => !new_followers.find((f) => f.username === item.username)
  );
  const notFollowingThem = new_followers.filter(
    (item) => !new_following.find((f) => f.username === item.username)
  );

  const notFollowingYouCnt = notFollowingYou.length;
  const notFollowingThemCnt = notFollowingThem.length;
  console.log(`notFollowingYou: ${notFollowingYou.length}`);
  console.log(`notFollowingThem: ${notFollowingThem.length}`);

  await browser.close();
  return {
    notFollowingYou,
    notFollowingThem,
    notFollowingYouCnt,
    notFollowingThemCnt,
  };
};

async function scrollDown(selector, page) {
  await page.evaluate(async (selector) => {
    const section = document.querySelector(selector);
    await new Promise((resolve, reject) => {
      let totalHeight = 0;
      let distance = 100;
      const timer = setInterval(() => {
        var scrollHeight = section.scrollHeight;
        section.scrollTop = 100000000;
        totalHeight += distance;
        if (totalHeight >= scrollHeight) {
          clearInterval(timer);
          resolve();
        }
      }, 500);
    });
  }, selector);
}

module.exports = { script };
// script();
